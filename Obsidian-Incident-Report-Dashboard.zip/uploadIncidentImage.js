const { dialog } = require('electron').remote;
const path = require('path');
const fs = require('fs').promises;

module.exports = async () => {
  // Let user pick an image
  const result = await dialog.showOpenDialog({
    properties: ["openFile"],
    filters: [{ name: "Images", extensions: ["png","jpg","jpeg","gif","webp"] }]
  });
  if (result.canceled) return;

  const src = result.filePaths[0];
  const originalName = path.basename(src);
  const destFolder = "Incident Reports/Images";

  // Ensure folder exists
  if (!app.vault.getAbstractFileByPath(destFolder)) {
    await app.vault.createFolder(destFolder);
  }

  // Get the active file
  const activeFile = app.workspace.getActiveFile();
  if (!activeFile) return;

  const fileContent = await app.vault.read(activeFile);
  const match = fileContent.match(/^title:\s*(.+)$/m);
  const reportId = match ? match[1].trim() : "Incident-Report";

  // Build new filename with report ID prefix
  const fileName = `${reportId}-${originalName}`;
  const destPath = destFolder + "/" + fileName;

  // Copy the file into the vault
  const data = await fs.readFile(src);
  await app.vault.createBinary(destPath, data);

  new Notice("Image uploaded: " + fileName);

  // Replace the placeholder line with heading + embed
  let updated;
  if (fileContent.includes("**Incident Image**: None yet")) {
    updated = fileContent.replace(
      "**Incident Image**: None yet",
      `### Incident Image\n\n![[${fileName}|500]]`
    );
  } else {
    updated = fileContent + `\n\n### Incident Image\n\n![[${fileName}|500]]`;
  }

  await app.vault.modify(activeFile, updated);

  // THIS LINE MUST BE INSIDE THE FUNCTION
  await app.fileManager.processFrontMatter(activeFile, (fm) => {
    fm.image_uploaded = true;
  });
};