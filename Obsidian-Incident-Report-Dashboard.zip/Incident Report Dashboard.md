<center><h1><strong>Incident Management Dashboard</strong></h1></center>

<div align="center" style="font-size:1.1em; margin-top:0.3rem;">
  A living record of safety, stewardship, and shared responsibility <br>
  Tracking issues, assignments, and resolutions across the community
</div>

---

```dataviewjs
// ---------- CSS for the 3-card overview row ----------
const style = document.createElement("style");
style.textContent = `
  .markdown-preview-view hr,
  .markdown-rendered hr {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
  }

  .incident-overview-row {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
    margin: 1.5rem 0 2rem 0;
  }

  .incident-overview-card {
    padding: 1rem;
    border: 1px solid var(--background-modifier-border);
    border-radius: 8px;
    background-color: var(--background-secondary);
    text-align: center;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  }

  .incident-overview-card h3 {
    margin: 0;
    font-size: 1.1em;
    font-weight: 600;
  }

  .incident-overview-number {
    font-size: 2.2em;
    font-weight: 700;
    margin: 0.3rem 0 0.2rem 0;
  }

  .incident-overview-sub {
    font-size: 0.9em;
    color: var(--text-muted);
  }
`;
document.head.appendChild(style);

// ---------- DATA ----------
const files = dv.pages('"Incident Reports"')
  .where(p => p.file.name !== "Incident Report Dashboard");

const openCount   = String(files.where(p => p.status === "open").length       || 0);
const inProgCount = String(files.where(p => p.status === "in-progress").length || 0);
const closedCount = String(files.where(p => p.status === "closed").length     || 0);

// ---------- RENDER ----------
const row = dv.container.createDiv({ cls: "incident-overview-row" });

// Card builder
function makeCard(parent, title, number, subtext) {
  const card = parent.createDiv({ cls: "incident-overview-card" });
  card.createEl("h3", { text: title });
  card.createDiv({ cls: "incident-overview-number", text: number });
  card.createDiv({ cls: "incident-overview-sub", text: subtext });
}

// Create the 3 cards
makeCard(row, "Open",        openCount,   "Active issues");
makeCard(row, "In‑Progress", inProgCount, "Being worked on");
makeCard(row, "Closed",      closedCount, "Resolved reports");
```

---

```dataviewjs
const files = dv.pages('"Incident Reports"')
  .where(p => p.file.name !== "Incident Report Dashboard");

const monthlySeverity = {};

for (let p of files) {
  if (!p.report_date || !p.severity) continue;

  const m = dv.date(p.report_date).toFormat("yyyy-MM");
  if (!monthlySeverity[m]) {
    monthlySeverity[m] = { low: 0, medium: 0, high: 0 };
  }
  monthlySeverity[m][p.severity] += 1;
}

const today = dv.date("today");
const twelveMonthsAgo = today.minus({ months: 12 });

const sortedMonths = Object.keys(monthlySeverity)
  .filter(m => dv.date(m + "-01") >= twelveMonthsAgo)
  .sort()
  .reverse();

dv.header(2, "Severity Trends Over 12 Months");

if (sortedMonths.length === 0) {
  dv.paragraph("→ No reports with valid 'report_date' and 'severity' in the last 12 months.");
} else {
  const container = dv.container.createDiv({
    attr: { class: "severity-trend-container", style: "margin: 1.5rem 0 2.5rem 0;" }
  });

  const style = document.createElement("style");
  style.textContent = `
    .severity-trend-row {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 10px 12px;
      border-radius: 8px;
      background: var(--background-secondary);
      border: 1px solid var(--background-modifier-border);
      margin-bottom: 8px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }
    .severity-month {
      width: 160px;
      font-weight: 600;
      text-align: left;
      color: var(--text-normal);
    }
    .severity-bar-wrapper {
      flex: 1;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      gap: 16px;
    }
    .severity-bar {
      display: flex;
      height: 28px;
      align-items: center;
      gap: 3px;
      min-width: 80px;
    }
    .severity-percent {
      font-size: 0.85em;
      color: var(--text-muted);
      white-space: nowrap;
      min-width: 110px;
      text-align: right;
    }
    .severity-total {
      width: 50px;
      font-weight: bold;
      text-align: center;
      color: var(--text-muted);
    }
    .severity-legend {
      display: flex;
      gap: 20px;
      justify-content: center;
      margin-top: 1.2rem;
      font-size: 0.95em;
      color: var(--text-muted);
    }
  `;
  document.head.appendChild(style);

  for (let ym of sortedMonths) {
    const data = monthlySeverity[ym];
    const total = data.low + data.medium + data.high;

    const row = container.createDiv({ cls: "severity-trend-row" });

    row.createEl("div", {
      text: dv.date(ym + "-01").toFormat("MMMM yyyy"),
      cls: "severity-month"
    });

    const barWrapper = row.createDiv({ cls: "severity-bar-wrapper" });

    const bar = barWrapper.createDiv({ cls: "severity-bar" });
    if (data.low    > 0) bar.createEl("span", { text: "🟢".repeat(data.low),    attr: { title: `${data.low} low` } });
    if (data.medium > 0) bar.createEl("span", { text: "🟡".repeat(data.medium), attr: { title: `${data.medium} medium` } });
    if (data.high   > 0) bar.createEl("span", { text: "🔴".repeat(data.high),   attr: { title: `${data.high} high` } });

    if (total > 0) {
      const pctLow    = Math.round((data.low    / total) * 100);
      const pctMedium = Math.round((data.medium / total) * 100);
      const pctHigh   = Math.round((data.high   / total) * 100);

      const pctText = [
        pctLow    ? `${pctLow}% L`    : "",
        pctMedium ? `${pctMedium}% M` : "",
        pctHigh   ? `${pctHigh}% H`   : ""
      ].filter(Boolean).join(" / ") || "—";

      barWrapper.createEl("span", {
        text: pctText,
        cls: "severity-percent"
      });
    } else {
      barWrapper.createEl("span", { text: "", cls: "severity-percent" });
    }

    barWrapper.createEl("div", { text: total, cls: "severity-total" });
  }

  const legend = container.createDiv({ cls: "severity-legend" });
  legend.createEl("span", { text: "🟢 Low" });
  legend.createEl("span", { text: "🟡 Medium" });
  legend.createEl("span", { text: "🔴 High" });
}
```

---

```dataviewjs
try {
  const el = dv.el("div", "");
  el.innerHTML = `
    <style>
      .form-container { max-width: 100%; margin: 0 auto; font-family: var(--font-text, "Georgia", serif); }
      .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
      .form-group { margin-bottom: 15px; }
      .form-group label { display: block; font-weight: bold; margin-bottom: 5px; color: var(--text-normal); }
      .form-group input, .form-group textarea { width: 100%; padding: 8px; border: 1px solid var(--background-modifier-border); border-radius: 4px; background: var(--background-secondary); color: var(--text-normal); }
      .form-group textarea { grid-column: 1 / -1; }
      .checkbox-group, .radio-group { margin-bottom: 20px; grid-column: 1 / -1; }
      .checkbox-group h3, .radio-group h3 { margin-bottom: 10px; color: var(--text-accent); }
      .form-button { background: var(--interactive-accent); color: var(--text-on-accent); padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
      .error { color: var(--text-error); }

/* Info card beside severity + incident type */
.form-mid-wrapper {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  align-items: start;
  margin-top: 12px;
}

.info-card {
  background: var(--background-secondary);
  border: 1px solid var(--background-modifier-border);
  border-radius: 6px;
  padding: 12px 14px;
  margin-top: 0px;
  color: var(--text-normal);
  font-size: 0.9em;
}

.radio-group h3,
.checkbox-group h3,
.info-card h3 {
  margin-top: 0;
  margin-bottom: 8px;
  color: var(--text-accent);
  font-size: 1.1em;   /* pick a size you like */
  font-weight: 600;   /* or 500 if this feels too heavy */
}


    </style>
    <div class="form-container">
      <h2>Incident Report Form</h2>
      <form id="incident-report-form">
        <div class="form-grid">
          <div class="form-group">
            <label for="reporter">Report Made By</label>
            <input type="text" id="reporter" required>
          </div>
          <div class="form-group">
            <label for="contact">Contact Info (Optional)</label>
            <input type="text" id="contact" placeholder="Phone or Email">
          </div>
          <div class="form-group">
            <label for="report_date">Date of Report</label>
            <input type="date" id="report_date" value="${(() => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0'); })()}" required>
          </div>
          <div class="form-group">
            <label for="incident_date">Incident Date</label>
            <input type="date" id="incident_date" required>
          </div>
          <div class="form-group">
            <label for="incident_time">Incident Time</label>
            <input type="time" id="incident_time" required>
          </div>
          <div class="form-group">
            <label for="location">Location</label>
            <input type="text" id="location" placeholder="e.g., Common hallway">
          </div>
        </div>
<div class="form-mid-wrapper">

  <div>
    <div class="radio-group">
      <h3>Severity</h3>
      <label><input type="radio" name="severity" id="severity-low" value="low" required> Low (annoying but not urgent)</label><br>
      <label><input type="radio" name="severity" id="severity-medium" value="medium"> Medium (needs attention soon)</label><br>
      <label><input type="radio" name="severity" id="severity-high" value="high"> High (immediate danger)</label><br>
    </div>

    <div class="checkbox-group">
      <h3>Incident Type</h3>
      <label><input type="checkbox" id="type-0"> Noise complaint</label><br>
      <label><input type="checkbox" id="type-1"> Maintenance issue</label><br>
      <label><input type="checkbox" id="type-2"> Safety hazard</label><br>
      <label><input type="checkbox" id="type-3"> Neighbor dispute</label><br>
      <label><input type="checkbox" id="type-4"> Parking issue</label><br>
      <label><input type="checkbox" id="type-5"> Theft or vandalism</label><br>
      <label><input type="checkbox" id="type-6"> Other</label><br>
    </div>
  </div>

  <!-- INFO CARD -->
  <div class="info-card">
    <h3>Quick Guidance</h3>
    <ul>
      <li>Describe what happened using specific, factual details</li>
      <li>Include dates, times, locations, and who was involved</li>
      <li>Focus on what you directly observed</li>
      <li>Note any actions you took or assistance provided</li>
      <li>Mention ongoing concerns or risks</li>
      <li>If unsure whether to report something, include it anyway</li>
    </ul>
  </div>

</div>
        <div class="form-group">
          <label for="description">Detailed Description</label>
          <textarea id="description" rows="6" required></textarea>
        </div>
        <div class="form-group">
          <label for="actions">Actions Taken (if any)</label>
          <textarea id="actions" rows="4"></textarea>
        </div>
        <div class="form-group">
          <label for="resolution">Requested Resolution</label>
          <textarea id="resolution" rows="4"></textarea>
        </div>
        <button type="submit" class="form-button">Submit Incident Report</button>
        <p></p>
      </form>
      <div id="error-message" class="error"></div>
    </div>
  `;

  const form = el.querySelector("#incident-report-form");
  form.addEventListener("submit", async function(e) {
    e.preventDefault();
    try {
      const formData = {
        reporter: form.querySelector("#reporter").value.trim() || "Anonymous",
        contact: form.querySelector("#contact").value.trim() || "",
        report_date: form.querySelector("#report_date").value || new Date().toISOString().split('T')[0],
        incident_date: form.querySelector("#incident_date").value || "",
        incident_time: form.querySelector("#incident_time").value || "",
        location: form.querySelector("#location").value.trim() || "",
        severity: form.querySelector("input[name='severity']:checked")?.value || "",
        type: [
          { text: "Noise complaint", checked: form.querySelector("#type-0").checked },
          { text: "Maintenance issue", checked: form.querySelector("#type-1").checked },
          { text: "Safety hazard", checked: form.querySelector("#type-2").checked },
          { text: "Neighbor dispute", checked: form.querySelector("#type-3").checked },
          { text: "Parking issue", checked: form.querySelector("#type-4").checked },
          { text: "Theft or vandalism", checked: form.querySelector("#type-5").checked },
          { text: "Other", checked: form.querySelector("#type-6").checked }
        ],
        description: form.querySelector("#description").value.trim() || "",
        actions: form.querySelector("#actions").value.trim() || "",
        resolution: form.querySelector("#resolution").value.trim() || ""
      };

      // Validation
      if (!formData.reporter || !formData.incident_date || !formData.incident_time || !formData.severity) {
        throw new Error("Please fill out all required fields: Reporter, Incident Date, Incident Time, and Severity.");
      }

      // Format date for filename
      const [year, month, day] = formData.report_date.split('-').map(Number);
      const formattedDate = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      
      // Check for existing files to append counter if needed
      const folder = "Incident Reports";
      let baseFileName = `${formattedDate}-Incident-Report`;
      let fileName = `${folder}/${baseFileName}.md`;
      let counter = 1;
      while (app.vault.getAbstractFileByPath(fileName)) {
        fileName = `${folder}/${baseFileName}-${String(counter).padStart(3, '0')}.md`;
        counter++;
      }

      // Create folder if it doesn't exist
      if (!app.vault.getAbstractFileByPath(folder)) {
        await app.vault.createFolder(folder);
      }

      // Helper functions
      const formatDate = (dateStr) => {
        const [year, month, day] = dateStr.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString('en-US', options);
      };
      const formatTime = (timeStr) => {
        const [hours, minutes] = timeStr.split(':').map(Number);
        const period = hours >= 12 ? 'PM' : 'AM';
        const adjustedHours = hours % 12 || 12;
        return `${adjustedHours}:${String(minutes).padStart(2, '0')} ${period}`;
      };

      // Generate severity emoji
      const severityEmoji = formData.severity === "high" ? "🔴" : formData.severity === "medium" ? "🟡" : "🟢";

      // Create Markdown content
      let content = `---
title: ${baseFileName}${counter > 1 ? '-' + String(counter-1).padStart(3, '0') : ''}
reporter: ${formData.reporter}
report_date: ${formData.report_date}
incident_date: ${formData.incident_date}
incident_time: ${formData.incident_time}
location: ${formData.location}
severity: ${formData.severity}
type: [${formData.type.filter(item => item.checked).map(item => item.text).join(", ")}]
tags: [incident-report, maintenance, safety]
status: open
---
# Incident Report

**Report ID**: ${baseFileName}${counter > 1 ? '-' + String(counter-1).padStart(3, '0') : ''}

**Report Made By**: ${formData.reporter}
**Date of Report**: ${formatDate(formData.report_date)}

<table class="incident-table" style="width:100%; border-collapse: collapse;">
<tr style="background-color: var(--background-secondary);">
<th style="border: 1px solid var(--background-modifier-border); padding: 8px;">Key Details</th>
<th style="border: 1px solid var(--background-modifier-border); padding: 8px;">Info</th>
</tr>
<tr>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;"><strong>Date/Time of Incident</strong></td>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;">${formatDate(formData.incident_date)} at ${formatTime(formData.incident_time)}</td>
</tr>
<tr>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;"><strong>Location</strong></td>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;">${formData.location}</td>
</tr>
<tr>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;"><strong>Severity</strong></td>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;">${formData.severity.charAt(0).toUpperCase() + formData.severity.slice(1)} ${severityEmoji}</td>
</tr>
<tr>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;"><strong>Incident Types</strong></td>
<td style="border: 1px solid var(--background-modifier-border); padding: 8px;">${formData.type.filter(item => item.checked).map(item => item.text).join(", ")}</td>
</tr>
</table>



\`\`\`dataviewjs
if (dv.current().file.frontmatter["image_uploaded"] !== true) {

  const btn = this.container.createEl("button", {
    text: "Upload Incident Image",
    attr: { 
      style: "padding:8px 12px; color:var(--text-normal); border:1px solid var(--background-modifier-border); border-radius:6px; cursor:pointer; font-size:0.7em; font-weight:400; transition:all 0.15s ease;"
    }
  });

  btn.onclick = async () => {
    app.commands.executeCommandById("quickadd:choice:YOUR-ID-HERE");
  };
}
\`\`\`

### Detailed Description
${formData.description}

### Actions Taken
${formData.actions || "None reported."}

### Requested Resolution
${formData.resolution || "None specified."}

### Status Updates
- **${formatDate(formData.report_date)}**: Report filed.

**Status**: Open | **Assigned To**: Unassigned
${formData.contact ? `*For questions, contact **${formData.reporter}** at ${formData.contact}.*` : ""}

**Incident Image**: None yet
`;

      // Save the file
      await app.vault.create(fileName, content);
      dv.el("p", `Incident report created: [[${fileName}]]`);

      // Auto-inject edit button + update form
      setTimeout(async () => {
        const file = app.vault.getFileByPath(fileName);
        if (!file) return;
        let text = await app.vault.read(file);

        const editBlock = [
          "---",
          "### Update this Report",
          "",
          "```dataviewjs",
          "(async () => {",
          "  const container = dv.container;",
          "  if (!container) return;",
          "  container.innerHTML = '';",
          "",
          "  container.createEl('strong', { text: 'Overall status:' });",
          "  const sel = container.createEl('select', { attr: { style: 'width:100%; padding:6px; margin:8px 0;' } });",
          "  ['open','in-progress','closed'].forEach(s => {",
          "    const label = s === 'in-progress' ? 'In Progress' : s.charAt(0).toUpperCase() + s.slice(1);",
          "    const opt = sel.createEl('option', { text: label, value: s });",
          "    if ((dv.current().file.frontmatter?.status || 'open') === s) opt.selected = true;",
          "  });",
          "",
          "  let currentAssigned = 'Unassigned';",
          "  try {",
          "    const text = await dv.io.load(dv.current().file.path);",
          "    const m = text.match(/\\*\\*Status\\*\\*: [^|]*\\| \\*\\*Assigned To\\*\\*: (.*)/i);",
          "    if (m?.[1]) currentAssigned = m[1].trim();",
          "  } catch(e) {}",
          "",
          "  container.createEl('p', { text: 'Assign to (optional):', attr: { style: 'margin:8px 0 4px;' } });",
          "  const assignedInput = container.createEl('input', {",
          "    attr: { type: 'text', placeholder: 'e.g. Officer Smith', style: 'width:100%; padding:6px;' },",
          "    value: currentAssigned === 'Unassigned' ? '' : currentAssigned",
          "  });",
          "",
          "  container.createEl('p', { text: 'New status update (optional):', attr: { style: 'margin:8px 0 4px;' } });",
          "  const ta = container.createEl('textarea', {",
          "    attr: { placeholder: 'e.g. Issue resolved – lock replaced', rows: 4, style: 'width:100%; padding:8px;' }",
          "  });",
          "",
		  "  container.createEl('p');",          // ← adds ~1 line of vertical space
          "  const btn = container.createEl('button', {",
          "    text: 'Update Status',",
          "    attr: { style: 'padding:8px 12px; color:var(--text-normal); border:1px solid var(--background-modifier-border); border-radius:6px; cursor:pointer; font-size:0.7em; font-weight:400; transition:all 0.15s ease;' }",
          "  });",
          "",
          "  const msg = container.createEl('div', { attr: { style: 'margin-top:10px; font-weight:bold;' } });",
          "",
          "  btn.onclick = async () => {",
          "    btn.disabled = true;",
          "    try {",
          "      const note = ta.value.trim();",
          "      const newStatus = sel.value;",
          "      const inputVal = assignedInput.value.trim();",
          "      const assignedTo = inputVal || 'Unassigned';",
          "",
          "      const activeFile = app.workspace.getActiveFile();",
          "      if (!activeFile) throw new Error('No active file');",
          "",
          "      let fileContent = await app.vault.read(activeFile);",
          "",
          "      if (note) {",
          "        const today = dv.date('today').toFormat('LLLL d, yyyy');",
          "        fileContent = fileContent.replace(/(### Status Updates\\n)/, `$1- **${today}**: ${note}\\n`);",
          "      }",
          "",
          "      fileContent = fileContent.replace(/^status:\\s*.+$/m, 'status: ' + newStatus);",
          "",
          "      const pretty = newStatus === 'in-progress' ? 'In Progress' : newStatus.charAt(0).toUpperCase() + newStatus.slice(1);",
          "      fileContent = fileContent.replace(/\\*\\*Status\\*\\*:.*/, '**Status**: ' + pretty + ' | **Assigned To**: ' + assignedTo);",
          "",
          "      await app.vault.modify(activeFile, fileContent);",
          "",
          "      msg.style.color = 'var(--text-success)';",
          "      msg.textContent = 'Report updated!';",
          "      ta.value = '';",
          "      setTimeout(() => dv.refresh?.(), 150);",
          "    } catch (err) {",
          "      msg.style.color = 'var(--text-error)';",
          "      msg.textContent = 'Error: ' + (err.message || err);",
          "    } finally {",
          "      btn.disabled = false;",
          "    }",
          "  };",
          "})();",
          "```",
        ].join("\n");

        if (!text.includes("### Update this Report")) {
          text += "\n" + editBlock;
        }

        await app.vault.modify(file, text);
      }, 800);

    } catch (error) {
      const errorDiv = el.querySelector("#error-message");
      errorDiv.innerText = `Error creating report: ${error.message}`;
    }
  });
} catch (e) {
  dv.el("p", `Error loading form: ${e.message}`);
}
```

---

```dataviewjs
// ---------- CSS (injected dynamically) ----------
const style = document.createElement("style");
style.textContent = `
  .incident-card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
  }

  .incident-card {
    padding: 1rem;
    border: 1px solid var(--background-modifier-border);
    border-radius: 8px;
    background-color: var(--background-secondary);
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    display: flex;
    flex-direction: column;
  }

  /* Reduced spacing under the summary */
  .incident-summary {
    margin-bottom: 0.25rem;
  }

  .incident-summary h4 {
    margin: 0;
    line-height: 1.4em;
    font-size: 1.03rem;
  }

  /* Metadata still bottom-aligned */
  .incident-bottom {
    margin-top: auto;
  }

  .incident-card p {
    margin: 0.15rem 0;
  }

  .incident-open-link {
    color: var(--text-accent);
    cursor: pointer;
    margin-top: 0.4rem;
    display: inline-block;
  }
`;
document.head.appendChild(style);

// ---------- HELPERS ----------
const severityEmoji = s =>
  s === "high"   ? "🔴" :
  s === "medium" ? "🟡" :
  "🟢";

const statusColor = s =>
  s === "closed"     ? "var(--text-normal)" :
  s === "in-progress" ? "var(--text-normal)" :
  "var(--text-normal)";

// ---------- DATA FETCH ----------
const files = dv.pages('"Incident Reports"')
  .where(p => p.file.name !== "Incident Report Dashboard");

// ---------- DASHBOARD ----------
dv.header(2, "Current Incidents at a Glance");

for (let status of ["open", "in-progress", "closed"]) {
  const label = status === "in-progress" ? "In Progress" : status.charAt(0).toUpperCase() + status.slice(1);
  dv.header(4, label);

  const group = files.where(p => p.status === status);
  const container = dv.container.createDiv({ cls: "incident-card-grid" });

  for (let page of group) {
    const text = await dv.io.load(page.file.path);

    // Extract Assigned To
    const m = text.match(/\*\*Status\*\*: [^|]*\| \*\*Assigned To\*\*: (.*)/i);
    const assigned = m?.[1]?.trim() || "Unassigned";

    // Extract first sentence of Detailed Description for preview
    let displayTitle = page.title;
    const descMatch = text.match(/### Detailed Description\s+([\s\S]*?)(\n###|$)/i);
    if (descMatch) {
      let firstLine = descMatch[1].trim().split(/\.\s+/)[0];
      if (firstLine) {
        const maxChars = 58;
        if (firstLine.length > maxChars) {
          firstLine = firstLine.slice(0, maxChars).trim() + "...";
        }
        displayTitle = firstLine;
      }
    }

    const card = container.createDiv({ cls: "incident-card" });

    // Summary (top)
    const summary = card.createDiv({ cls: "incident-summary" });
    summary.createEl("h4", { text: displayTitle });

    // Metadata (bottom)
    const bottom = card.createDiv({ cls: "incident-bottom" });

    // Report filename
    const titleLine = bottom.createEl("p", { text: page.file.name });
    titleLine.style.color = "var(--text-accent)";

    // Incident date
    const dateStr = dv.date(page.incident_date).toFormat("MMMM d, yyyy");
    bottom.createEl("p", { text: `Date: ${dateStr}` });

    // Severity
    bottom.createEl("p", {
      text: `Severity: ${page.severity} ${severityEmoji(page.severity)}`
    });

    // Assigned
    bottom.createEl("p", { text: `Assigned To: ${assigned}` });

    // Status
    const statusLine = bottom.createEl("p", {
      text: `Status: ${page.status}`
    });
    statusLine.style.color = statusColor(page.status);

    // Link
    const link = bottom.createEl("span", { text: "Open Report", cls: "incident-open-link" });
    link.onclick = () => app.workspace.openLinkText(page.file.path, page.file.path);
  }
}
```

---

```dataviewjs
// ===== SEARCH INCIDENT REPORTS =====
const INCIDENTS_FOLDER = "Incident Reports";

// Simple debounce
function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

// Helpers
const severityEmoji = s => s === "high" ? "🔴" : s === "medium" ? "🟡" : "🟢";
const statusColor = s => s === "closed" ? "var(--text-success)" : s === "in-progress" ? "var(--text-accent)" : "var(--text-muted)";

// UI
dv.header(2, "Search Existing Incident Reports");

const controls = dv.el("div", "");
controls.style.cssText = "display:flex; flex-wrap:wrap; gap:12px; align-items:center; background:var(--background-secondary); padding:12px; border-radius:8px; margin-bottom:1rem;";

const searchInput = controls.createEl("input", { placeholder: "Search description, actions, updates…", type: "text" });
searchInput.style.flex = "1 1 300px";
searchInput.style.padding = "10px";
searchInput.style.fontSize = "1em";

const sevSel = controls.createEl("select");
sevSel.createEl("option", { text: "All Severities", value: "" });
["low","medium","high"].forEach(s => sevSel.createEl("option", { text: s.charAt(0).toUpperCase()+s.slice(1), value: s }));

const statSel = controls.createEl("select");
statSel.createEl("option", { text: "All Statuses", value: "" });
["open","in-progress","closed"].forEach(s => {
  const label = s === "in-progress" ? "In Progress" : s.charAt(0).toUpperCase() + s.slice(1);
  statSel.createEl("option", { text: label, value: s });
});

// Results + pagination containers
const resultsDiv = dv.el("div");
const paginationHolder = dv.el("div", "");
paginationHolder.style.cssText = "margin-top:8px; display:flex; gap:8px; align-items:center; justify-content:center;";

// Pagination settings
const REPORTS_PER_PAGE = 10;
let lastPage = 1;

// Main search function
async function runSearch(page = 1) {
  resultsDiv.innerHTML = "<p><em>Loading reports…</em></p>";
  paginationHolder.innerHTML = "";

  const query = searchInput.value.trim().toLowerCase();
  const sev = sevSel.value;
  const stat = statSel.value;

  let pages = dv.pages(`"${INCIDENTS_FOLDER}"`)
    .where(p => p.tags && String(p.tags).toLowerCase().includes("incident-report"))
    .sort(p => p.report_date, "desc");

  const hits = [];

  for (const p of pages) {
    if (sev && p.severity !== sev) continue;
    if (stat && p.status !== stat) continue;

    if (query) {
      const body = (await dv.io.load(p.file.path)) || "";
      const text = body.replace(/^---[\s\S]*?---/, "").toLowerCase();
      if (!text.includes(query)) continue;
    }

    let assigned = "Unassigned";
    const body = await dv.io.load(p.file.path);
    const m = body.match(/\*\*Assigned To\*\*: (.*?)(?=\n|$)/i);
    if (m) assigned = m[1].trim();

    hits.push({ page: p, assigned });
  }

  // Pagination
  const totalPages = Math.max(1, Math.ceil(hits.length / REPORTS_PER_PAGE));
  const currentPage = Math.min(page, totalPages);
  lastPage = currentPage;

  const pageReports = hits.slice(
    (currentPage - 1) * REPORTS_PER_PAGE,
    currentPage * REPORTS_PER_PAGE
  );

  // Render
  resultsDiv.innerHTML = "";

  if (pageReports.length === 0) {
    resultsDiv.createEl("p", { text: "No reports found.", style: "text-align:center; color:var(--text-muted);" });
    return;
  }

  const table = resultsDiv.createEl("table", { cls: "table" });
  table.style.width = "100%";

  // Header
  table.createEl("thead").createEl("tr", {}, tr => {
    ["Date", "Reporter", "Severity", "Types", "Status", "Assigned", "Link"].forEach(h =>
      tr.createEl("th", { text: h, style: "text-align:left; padding:6px 8px;" })
    );
  });

  // Body
  const tbody = table.createEl("tbody");
  pageReports.forEach(h => {
    const p = h.page;
    const row = tbody.createEl("tr");
    row.style.borderBottom = "1px solid var(--background-modifier-border)";

    const dateStr = dv.date(p.incident_date).toFormat("MMM d, yyyy");
    const types = Array.isArray(p.type) ? p.type.join(", ") : "";

    row.createEl("td", { text: dateStr, style: "padding:6px 8px;" });
    row.createEl("td", { text: p.reporter || "", style: "padding:6px 8px;" });

    const sevCell = row.createEl("td", { style: "padding:6px 8px;" });
    sevCell.style.display = "flex";
    sevCell.style.justifyContent = "space-between";
    sevCell.style.alignItems = "center";
    sevCell.createEl("span", { text: p.severity?.charAt(0).toUpperCase() + p.severity?.slice(1) || "" });
    sevCell.createEl("span", { text: severityEmoji(p.severity) });

    row.createEl("td", { text: types, style: "padding:6px 8px;" });
    row.createEl("td", {
      text: p.status ? p.status.charAt(0).toUpperCase() + p.status.slice(1).replace("-", " ") : "Open",
      style: `padding:6px 8px; color:${statusColor(p.status)}`
    });
    row.createEl("td", { text: h.assigned === "Unassigned" ? "" : h.assigned, style: "padding:6px 8px;" });

    const linkTd = row.createEl("td", { style: "padding:6px 8px; text-align:right;" });
    const link = linkTd.createEl("a", { href: p.file.path, text: "Open →" });
    link.addClass("internal-link");
    link.style.color = "var(--text-accent)";
  });

  resultsDiv.createEl("p", {
    text: `Found ${hits.length} report${hits.length !== 1 ? "s" : ""}.`,
    style: "margin-top:1rem; text-align:center; color:var(--text-muted); font-size:0.9em;"
  });

  // Pagination controls
  paginationHolder.innerHTML = "";
  if (hits.length > REPORTS_PER_PAGE) {
    const prevBtn = paginationHolder.createEl("button", { text: "Previous" });
    prevBtn.disabled = currentPage === 1;
    paginationHolder.createEl("span", { text: ` Page ${currentPage} of ${totalPages} ` });
    const nextBtn = paginationHolder.createEl("button", { text: "Next" });
    nextBtn.disabled = currentPage === totalPages;

    prevBtn.addEventListener("click", () => runSearch(currentPage - 1));
    nextBtn.addEventListener("click", () => runSearch(currentPage + 1));
  }

  resultsDiv.appendChild(paginationHolder);
}

// Live updates
searchInput.addEventListener("input", () => runSearch(1));
sevSel.addEventListener("change", () => runSearch(1));
statSel.addEventListener("change", () => runSearch(1));

// Initial load
runSearch(1);
```

